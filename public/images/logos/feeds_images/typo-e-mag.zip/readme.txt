------------------
Typo E-mag
A CSS+(X)HTML-based template.
Designed by Mat�j Grabovsk� (mgrabovsky.is-game.com)
A nice typographic template, looks like a blog's main page. Main features are: nice color scheme, nice typography, nice sidebar (some people like to say "widget ready") and nice footer. I know that there are missing comments numbers, but who on the Earth does need comments? Main colors are #fff, #cfcfcf, #c40000, #666, and #444. Hope you like it. Yea, and it's my first template.
------------------

Dear friends,

thank you for downloading this file.

You can freely use this template for both your private and commercial projects, including software, online services, templates and themes.